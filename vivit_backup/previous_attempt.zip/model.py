
import timm
import torch
from vivit import FactorEncViViT

def get_model(device, num_classes=400):
    vit = timm.create_model("vit_base_patch16_224", pretrained=True).to(device)
    model = FactorEncViViT(
        vit=vit,
        num_frames=16,
        img_size=224,
        tempo_patch_size=4,
        spat_patch_size=16,
        num_classes=num_classes,
        pooling_mode="cls",
    ).to(device)
    return model

