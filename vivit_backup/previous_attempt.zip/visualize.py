import torch
import matplotlib.pyplot as plt
import numpy as np
from dataset import get_dataloader
from model import get_model

def visualize_predictions(model, dataloader, class_names, device="cuda"):
    model.eval()
    videos, _, labels = next(iter(dataloader))
    videos, labels = videos.to(device), labels.to(device)

    with torch.no_grad():
        outputs = model(videos)
        _, predictions = outputs.max(1)

    fig, axes = plt.subplots(1, len(videos), figsize=(15, 5))
    for i in range(len(videos)):
        img = videos[i, :, 0].cpu().numpy().transpose(1, 2, 0)  # First frame only
        axes[i].imshow(img)
        axes[i].set_title(f"Pred: {class_names[predictions[i].item()]}\nTrue: {class_names[labels[i].item()]}")
        axes[i].axis("off")

    plt.show()

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(device)

    # Load the trained model
    model.load_state_dict(torch.load("vivit_kinetics400.pth", map_location=device))
    model.eval()

    test_loader, class_to_idx = get_dataloader(root='./kinetics400_5per', split='val', batch_size=4)
    class_names = {v: k for k, v in class_to_idx.items()}  # Reverse class index mapping

    visualize_predictions(model, test_loader, class_names, device=device)