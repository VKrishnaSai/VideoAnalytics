import torch
import torch.optim as optim
import torch.nn as nn
from dataset import get_dataloader
from model import get_model
from torch.cuda.amp import autocast, GradScaler

def train(model, train_loader, criterion, optimizer, scheduler, num_epochs=10, device="cuda"):
    model.train()
    scaler = GradScaler('cuda')

    for epoch in range(num_epochs):
        running_loss = 0.0
        correct = 0
        total = 0

        for videos, labels in train_loader:
            videos, labels = videos.to(device, non_blocking=True), labels.to(device, non_blocking=True)
            optimizer.zero_grad()
            with autocast():
                outputs = model(videos)
                loss = criterion(outputs, labels)
            
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            _, predicted = outputs.max(1)
            correct += predicted.eq(labels).sum().item()
            total += labels.size(0)
        
        scheduler.step()
        print(f"Epoch {epoch+1}/{num_epochs}, Loss: {running_loss/len(train_loader)}, Accuracy: {correct/total:.4f}")

if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(device)
    train_loader = get_dataloader("./kinetics400_5per/train", batch_size=8)
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.1)
    
    train(model, train_loader, criterion, optimizer, scheduler, num_epochs=10, device=device)
    torch.save(model.state_dict(), "vivit_kinetics400.pth")
