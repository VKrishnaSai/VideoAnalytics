import torch
from dataset import get_dataloader
from model import get_model
from torch.cuda.amp import autocast

def evaluate(model, test_loader, device="cuda"):
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for videos, labels in test_loader:
            videos, labels = videos.to(device, non_blocking=True), labels.to(device, non_blocking=True)
            with autocast():
                outputs = model(videos)
            _, predicted = outputs.max(1)
            correct += predicted.eq(labels).sum().item()
            total += labels.size(0)
    
    print(f"Test Accuracy: {correct/total:.4f}")

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(device)
    model.load_state_dict(torch.load("vivit_kinetics400.pth", map_location=device))
    test_loader = get_dataloader("./kinetics400_5per/train", batch_size=8)
    evaluate(model, test_loader, device=device)
