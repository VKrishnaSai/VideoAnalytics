# dataset.py - Optimized Dataset Loader with Uniform Frame Sampling
import os
import torch
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import torchvision.io as io
import numpy as np
import torchvision.transforms.functional as F

class KineticsDataset(Dataset):
    def __init__(self, root, frames_per_clip=16):
        self.root = root
        self.video_paths = []
        self.labels = []
        self.class_to_idx = {}
        
        classes = sorted(os.listdir(root))  # Sort to maintain label consistency
        for idx, action in enumerate(classes):
            self.class_to_idx[action] = idx
            action_path = os.path.join(root, action)
            for file in os.listdir(action_path):
                if file.endswith(".mp4"):
                    self.video_paths.append(os.path.join(action_path, file))
                    self.labels.append(idx)

        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
        ])
    
    def __len__(self):
        return len(self.video_paths)

    import torchvision.transforms.functional as F

    def __getitem__(self, idx):
        video_path = self.video_paths[idx]
        frames, _, _ = io.read_video(video_path, pts_unit='sec')
        total_frames = frames.shape[0]

        if total_frames >= 16:
            indices = np.linspace(0, total_frames - 1, 16, dtype=int)  # Uniform sampling
        else:
            indices = np.pad(np.arange(total_frames), (0, 16 - total_frames), mode='wrap')

        frames = frames[indices]  # Select sampled frames
        frames = frames.float() / 255.0  # Normalize pixel values to [0,1]
        
        # Resize each frame individually
        resized_frames = torch.stack([F.resize(frame.permute(2, 0, 1), (224, 224)) for frame in frames])

        label = self.labels[idx]
        return resized_frames, label



def get_dataloader(root, batch_size=8, num_workers=8):
    dataset = KineticsDataset(root=root)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                            num_workers=num_workers, pin_memory=True, prefetch_factor=2)
    return dataloader

if __name__ == "__main__":
    train_loader = get_dataloader("./kinetics400_5per/train", batch_size=8)
    print(f"Loaded {len(train_loader.dataset)} training samples.")
